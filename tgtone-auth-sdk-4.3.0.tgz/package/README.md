# @tgtone/auth-sdk

SDK de autenticación centralizada para el ecosistema TGT One. OAuth PKCE + JWT + Session Cache via WebSocket.

```bash
npm install @tgtone/auth-sdk
```

---

## Uso básico

### React (hook)

```tsx
import { useTGTAuth } from '@tgtone/auth-sdk';

function App() {
  const { session, loading, logout, hasRole } = useTGTAuth({
    coreApiUrl: 'https://dev-core.tgtone.cl/api',
    appDomain: window.location.host,
    appKey: 'console',
  });

  if (loading) return <Spinner />;
  if (!session) return null; // redirigiendo al login

  return (
    <div>
      <span>{session.user.name}</span>
      <button onClick={logout}>Cerrar sesión</button>
      {hasRole('console', 'admin') && <AdminPanel />}
    </div>
  );
}
```

### Sin framework (TGTAuthClient)

```typescript
import { TGTAuthClient } from '@tgtone/auth-sdk';

const auth = new TGTAuthClient({
    coreApiUrl: 'https://dev-core.tgtone.cl/api',
  appDomain: window.location.host,
  appKey: 'console',
});

const session = await auth.checkSession();
if (session) {
  console.log('Usuario:', session.user.email);
}
```

---

## API rápida

| Método | Descripción |
|--------|-------------|
| `checkSession()` | Valida sesión, redirige a login si no hay |
| `checkSessionSilent()` | Valida sin redirigir |
| `redirectToLogin(url?)` | Redirige al login de Identity |
| `logout()` | Cierra sesión + redirige a login |
| `localLogout()` | Limpia sesión sin redirigir |
| `hasRole(app, role)` | Verifica rol del usuario |
| `hasAccessToApp(app)` | Verifica acceso a una app |
| `getToken()` | Obtiene JWT actual |
| `isRedirecting()` | `true` si está redirigiendo al login |
| `getBlockedRedirectUrl(error)` | URL de página bloqueada |
| `getApplicationRoles(appId)` | Obtiene roles de una aplicación desde el Core API |
| `listUsers(tenantId)` | Lista usuarios de un tenant desde el Core API |
| `startSessionMonitor()` | Inicia WS + refresh proactivo JWT |
| `stopSessionMonitor()` | Detiene WS + refresh |

### Gestión de usuarios (v4.3.0)

| Método | Descripción |
|--------|-------------|
| `inviteUser(data)` | Crear usuario + asignar roles + email de invitación |
| `updateUser(profileId, data)` | Actualizar perfil y/o roles de aplicación |
| `deleteUser(profileId)` | Desactivar usuario (soft delete + revocar sesiones) |
| `reactivateUser(profileId)` | Reactivar usuario eliminado |
| `resendInvitation(profileId)` | Reenviar email de invitación |
| `getUsersMap(tenantId)` | Mapa userId → nombre/email (solo activos) |
| `listUsers(tenantId)` | Lista usuarios de un tenant |
| `getApplicationRoles(appId)` | Roles disponibles de una app |

### Server-side (v4.3.0)

Para backends (Node/Bun), cron jobs y webhooks, existe `TGTAdminClient` — mismo API de gestión de usuarios, sin dependencias del DOM:

```typescript
import { TGTAdminClient } from '@tgtone/auth-sdk/server';

// Con JWT de admin reenviado, o con MAINTENANCE_API_KEY:
const admin = new TGTAdminClient({
  coreApiUrl: process.env.CORE_API_URL!,
  maintenanceKey: process.env.MAINTENANCE_API_KEY!, // o token: jwtDelRequest
});

const users = await admin.listUsers(tenantId);
```

Ver [`docs/USERS_MANAGEMENT.md`](./docs/USERS_MANAGEMENT.md) para patrones completos.

---

## Documentación

- [`docs/API.md`](./docs/API.md) — Referencia completa de API
- [`docs/USERS_MANAGEMENT.md`](./docs/USERS_MANAGEMENT.md) — Gestión de usuarios (frontend + backend)
- [`docs/ARCHITECTURE.md`](./docs/ARCHITECTURE.md) — OAuth PKCE, WS, session cache
- [`docs/INTEGRATION_EXAMPLES.md`](./docs/INTEGRATION_EXAMPLES.md) — Vue, Next.js, Angular
- [`CHANGELOG.md`](./CHANGELOG.md) — Historial de cambios

---

## Estructura del usuario

```typescript
interface TGTUser {
  sub: string;                          // ID del usuario
  email: string;
  emailVerified: boolean;
  name: string;
  tenantId: string;
  tenantName: string;
  roles: Record<string, string[]>;      // { console: ['admin'], baco: ['viewer'] }
}
```

---

## Migración desde v3 a v4

En v4, `identityUrl` pasó a llamarse `coreApiUrl`. El login, signup, auth, roles y usuarios están todos en el mismo Core API.

```diff
-  identityUrl: 'https://core.tgtone.cl',
+  coreApiUrl: 'https://core.tgtone.cl',
```

**Métodos nuevos:**

| Método | Reemplaza | Descripción |
|--------|-----------|-------------|
| `authClient.getApplicationRoles(appId)` | `core.applications.getRoles()` | Roles de una aplicación |
| `authClient.listUsers(tenantId)` | `core.users.list()` | Usuarios de un tenant |

Si estabas usando `@tgtone/core-sdk` solo para notificaciones, migra a `@tgtone/notifications-sdk`. Si lo usabas para auth, roles o usuarios, estos métodos ya están en `@tgtone/auth-sdk` v4.

## Licencia

Privado — TGT Group
